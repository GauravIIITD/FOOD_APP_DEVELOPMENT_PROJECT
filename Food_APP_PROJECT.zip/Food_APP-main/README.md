# Food_APP
Its a food app ,where user can order any dishes listed on the app .Here i store the data with the help of Sqlite
